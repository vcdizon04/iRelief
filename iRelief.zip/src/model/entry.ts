export interface Entry {
    emotion?: String;
    activities?: Array<any>;
    note?: String;
    logs?: Array<any>;
    date?: Number;
    doc?: any;
}