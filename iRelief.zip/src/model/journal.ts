export interface Journal {
    title?: String;
    content?: String;
    date?: Number;
    _id?: String;
    _rev?: String;
}