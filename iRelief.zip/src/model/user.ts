export interface User {
    name?: String;
    gender?: String;
}